# Technical Specs

Subcategoría de 05_Technology

## Archivos:

- README.md
- neural-sales-dashboard.html
