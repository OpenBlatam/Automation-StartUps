# Templates

Subcategoría de 06_Strategy

## Archivos:

- README.md
