
from .deepseek_v3 import create_deepseek_v3_model

__all__ = ['create_deepseek_v3_model']
