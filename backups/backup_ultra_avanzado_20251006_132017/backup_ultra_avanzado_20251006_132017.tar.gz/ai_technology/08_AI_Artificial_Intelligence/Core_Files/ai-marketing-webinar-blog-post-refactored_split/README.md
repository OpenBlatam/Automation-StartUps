# 📁 Índice de Archivos Divididos

**Archivo original:** ai-marketing-webinar-blog-post-refactored.md  
**Fecha de división:** 2025-10-06 13:18:33  
**Total archivos creados:** 7  
**Tamaño original:** 645,259 caracteres  

## 📄 Archivos Creados

1. **01__the_complete_guide_to_ai_marketing_webinars_trans.md**
   - Secciones: 190
   - Tamaño: 98,860 caracteres
   - Ruta: `ai_technology/08_AI_Artificial_Intelligence/Core_Files/ai-marketing-webinar-blog-post-refactored_split/01__the_complete_guide_to_ai_marketing_webinars_trans.md`

2. **02_the_full_range_of_possibilities.md**
   - Secciones: 140
   - Tamaño: 99,646 caracteres
   - Ruta: `ai_technology/08_AI_Artificial_Intelligence/Core_Files/ai-marketing-webinar-blog-post-refactored_split/02_the_full_range_of_possibilities.md`

3. **03_mastering_the_wave_of_transformation.md**
   - Secciones: 140
   - Tamaño: 99,552 caracteres
   - Ruta: `ai_technology/08_AI_Artificial_Intelligence/Core_Files/ai-marketing-webinar-blog-post-refactored_split/03_mastering_the_wave_of_transformation.md`

4. **04_your_orbital_platform_for_success.md**
   - Secciones: 136
   - Tamaño: 99,020 caracteres
   - Ruta: `ai_technology/08_AI_Artificial_Intelligence/Core_Files/ai-marketing-webinar-blog-post-refactored_split/04_your_orbital_platform_for_success.md`

5. **05_the_cellular_structure_of_success.md**
   - Secciones: 140
   - Tamaño: 99,953 caracteres
   - Ruta: `ai_technology/08_AI_Artificial_Intelligence/Core_Files/ai-marketing-webinar-blog-post-refactored_split/05_the_cellular_structure_of_success.md`

6. **06_optimizing_mental_processing_and_learning.md**
   - Secciones: 142
   - Tamaño: 99,169 caracteres
   - Ruta: `ai_technology/08_AI_Artificial_Intelligence/Core_Files/ai-marketing-webinar-blog-post-refactored_split/06_optimizing_mental_processing_and_learning.md`

7. **07_your_orbital_platform_for_success.md**
   - Secciones: 69
   - Tamaño: 49,059 caracteres
   - Ruta: `ai_technology/08_AI_Artificial_Intelligence/Core_Files/ai-marketing-webinar-blog-post-refactored_split/07_your_orbital_platform_for_success.md`


## 🔗 Navegación

- [Volver al archivo original](../ai-marketing-webinar-blog-post-refactored.md)
- [Ver todos los archivos divididos](./)

## 📊 Estadísticas

- **Reducción de tamaño promedio:** {reduction_percentage:.1f}%
- **Archivos más pequeños:** Mejor navegación y búsqueda
- **Organización mejorada:** Contenido estructurado por secciones
